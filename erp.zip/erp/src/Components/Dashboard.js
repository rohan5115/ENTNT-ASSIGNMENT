import React from 'react';
import './Dashboard.css'; 
import { Link } from 'react-router-dom'; 

function Dashboard() {
  
  const totalProducts = 12;
  const totalOrders = 4;

  return (
    
    <div><h1>Welcome To ERP Software !!!</h1>
    
    <div className="container">
      
      <div className="metricsContainer">
        <div className="metric">
          <Link to="/product">
            <h3>Total Products</h3>
            <p>{totalProducts}</p>
          </Link>
        </div>
        <div className="metric">
          <Link to="/order">
            <h3>Total Orders</h3>
            <p>{totalOrders}</p>
          </Link>
        </div>
        <div className="metric">
          <Link to="/calendar">
            <h3>Calendar View</h3>
            <p>Go to Calendar</p>
          </Link>
        </div>
        
      </div>
    </div>
    </div>
  );
}

export default Dashboard;
